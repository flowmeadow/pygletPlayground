#!/usr/bin/env python
# -*- encoding: utf-8 -*-
"""
@Introduce : TODO
@File      : __init__.py
@Project   : pygletPlayground
@Time      : 08.07.22 14:47
@Author    : flowmeadow
"""


def main():
    pass


if __name__ == "__main__":
    main()
