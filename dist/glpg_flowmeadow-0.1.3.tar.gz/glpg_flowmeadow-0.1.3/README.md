# PygletPlayground

> pyglet based OpenGL framework

### Installation

Simply run

    pip install glpg_flowmeadow


### Usage

Yep, I'll do this later ...